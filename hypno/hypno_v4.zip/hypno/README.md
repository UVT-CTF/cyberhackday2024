# Baby HypnoText Markup Language (HTML)
> author: Paul, Anca, category: steganography
### Description
Now you see me... Now you don't. Now you see me... Now you don't. Now you see me... Now your eyes hurt and the room may be spinning. Also, this sequence of states kind of reminds me of _binary_. Anyway, can you figure out the alluring message behind this website without falling into a trance?
### Flag
<details>
  <summary>Click to reveal the flag</summary>
HCamp{I_hOPE_YOUr_EYEs_DiDnT_RuN_AwAy}
</details>